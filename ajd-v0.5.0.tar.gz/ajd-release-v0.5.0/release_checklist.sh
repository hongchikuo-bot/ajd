#!/usr/bin/env bash
# AJD Release Checklist — Phase 5: GitHub Release v0.5.0 Final Stable

echo "=== AJD v0.5.0 Release Checklist ==="
echo ""

cd "$(dirname "$0")" || exit 1

all_ok=true

# ① Syntax checks
echo "① Syntax verification:"
bash -n install.sh > /dev/null && echo "   ✅ install.sh OK" || { echo "   ❌ install.sh"; all_ok=false; }
python3 -m py_compile app/app.py > /dev/null && echo "   ✅ app.py OK" || { echo "   ❌ app.py"; all_ok=false; }
python3 -m py_compile app/harvest.py > /dev/null && echo "   ✅ harvest.py OK"
bash -n scripts/demo_flow.sh > /dev/null && echo "   ✅ demo_flow.sh OK" || { echo "   ❌ demo_flow.sh"; all_ok=false; }
bash -n scripts/create_release_package.sh > /dev/null && echo "   ✅ create_release_package.sh OK" || { echo "   ❌ create_release_package.sh"; all_ok=false; }
python3 -m py_compile app/test_adapters.py > /dev/null && echo "   ✅ test_adapters.py OK"
echo ""

# ② Private data check
echo "② Private data check (app/ only):"
if grep -rIlE "macmima1234|kuohome|daily_run\.py|hckytbot" app/*.py 2>/dev/null | grep -v __pycache__ > /dev/null; then
  echo "   ❌ Found private data!"
  all_ok=false
else
  echo "   ✅ No private data in app/"
fi
echo ""

# ③ Required files
echo "③ Release package files:"
for f in LICENSE README.md README-zh.md AGENTS.md SETUP.md Dockerfile docker-compose.yml; do
  path="./$f"
  if [[ -f "$path" || -f "./app/$f" ]]; then
    echo "   ✅ $f"
  else
    echo "   ⚠️ Missing: $f"
  fi
done
# Check docs/screenshots for public repo
[[ -f "./docs/screenshot-desktop.png" ]] && echo "   ✅ screenshot-desktop.png (public)" || true
[[ -f "./docs/screenshot-mobile.png" ]] && echo "   ✅ screenshot-mobile.png (public)" || true
# ci files
[[ -f "./ci/github-actions.yml" ]] && echo "   ✅ github-actions.yml (for README link)" || true
[[ -f "./ci/README.md" ]] && echo "   ✅ CI README for docs" || true
# Release package
[[ -f "./ajd-v0.5.0.tar.gz" ]] && echo "   ✅ ajd-v0.5.0.tar.gz (release package)" || true
echo ""

# ④ README content check
echo "④ README files updated with v0.5.0:"
git -C ./ diff HEAD~1 -- README.md README-zh.md 2>/dev/null | grep -q "@@ .*RELEASE_NOTES" && \
  echo "   ✅ RELEASE_NOTES.md link in READMEs" || \
  [[ -f "./RELEASE_NOTES.md" ]] && echo "   ✅ RELEASE_NOTES.md exists (awaiting merge)"

echo ""

# ⑤ Version determination
echo "⑤ Determining release version:"
if grep -q "v0.5" README*.md; then
  echo "   → Recommended tag: 0.5.0 (Phase 5b complete - Final Stable)"
elif grep -q "version=" app/app.py | head -1 | grep -q "=0\.4"; then
  echo "   → Latest: check for new version string"
fi
echo ""

# ⑥ Summary
echo "⑥ Summary:"
if [[ "$all_ok" == true ]] && [[ -f "./RELEASE_NOTES.md" ]]; then
  echo "   ✅ Ready for GitHub release v0.5.0"
  echo "   → Create Release: https://github.com/hongchikuo-bot/ajd/releases/new"
  echo "   → Tag: 0.5.0"
  echo "   → Title: AJD v0.5.0 — Final Stable"
  echo "   → Body:"
  cat << 'RELEASER'
## What's New in v0.5.0

### 🎉 Final Stable Release — All Phases Complete

- ✅ **Phase 1-3 COMPLETE**: Engine, adapter layer, documentation ready
- ✅ **Phase 4 COMPLETE**: CI validation, clean install verification, endpoint consistency
- ✅ **Phase 5a COMPLETE**: AI Agents Setup Task Guide (AGENTS.md + SETUP.md integrated)
- ✅ **Phase 5b COMPLETE**: Demo flow script, release package (tar.gz), offline install verified

### 🔑 Core Features

- Heartbeat mechanism fully implemented (POST `/api/heartbeat`)
- Universal scheduler support (crontab, launchd, systemd timers, Hermes cron)
- Universal service monitoring (port, HTTP health, Docker)
- Agent-free setup via SETUP.md (works without any AI agent)
- AI agent setup guide (AGENTS.md) for Hermes, Claude, Cursor, etc.

### 📦 Installation Options

**Option 1: One-command deployment (recommended)**
```bash
curl -fsSL https://raw.githubusercontent.com/hongchikuo-bot/ajd/main/install.sh | bash
```

**Option 2: Offline / air-gapped install (tar.gz)**
```bash
# Download release asset: ajd-v0.5.0.tar.gz from GitHub Releases
tar -xzf ajd-v0.5.0.tar.gz
cd ajd-release-v0.5.0
AJD_HOME=/your/path PORT=5080 bash install.sh
```

**Option 3: Docker**
```bash
docker-compose up -d
```

### 🎯 Key Insight

> **"Ran but no heartbeat" is the most valuable alert.**

This is AJD's soul — cron says "I ran" but heartbeat proves "I finished successfully."

See [README.md](README.md) for full documentation.

RELEASER
else
  echo "   ⚠️ Some checks failed or RELEASE_NOTES.md missing"
fi
echo ""

# ⑦ Next steps
echo "⑦ Next steps:"
echo "   → If syntax checks pass: create GitHub release via GitHub UI or CLI"
echo "      gh repo release create --target main --title 'AJD v0.5.0 -- Final Stable' --draft"
echo "   → Copy RELEASE_NOTES.md as body (edit tag/version if needed)"
echo "   → Upload README screenshots:"
echo "      docs/screenshot-desktop.png → Attach to GitHub release notes"
echo "      docs/screenshot-mobile.png → Attach to GitHub release notes"
echo "   → Upload release package:"
echo "      ajd-v0.5.0.tar.gz → Attach as release asset"
echo ""

# Cleanup test server
pkill -f 'python3 app.py' 2>/dev/null || true
